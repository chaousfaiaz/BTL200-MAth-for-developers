---
name: Lab 1
about: Lab1 tasks
title: Lab 1 tasks
labels: ''
assignees: ''

---

Task list for lab

Perform analysis on following functions

- [ ] Do all the questions in part A
- [ ] Place your answers 1 per line into lab1a.txt
- [ ] Take images of your rough work
- [ ] Add images to the lab1.md file (images should be visible in file)
- [ ] Complete part B
- [ ] Complete part C  
