Sorry Sir due to covid I wasn't ablw to submit my work on time
MD FAIAZ 164899213

/*
Objective:
practice mathematical calculations involving exponents, logarithms and modulo
apply these calculations to problems in software development
Create the Repository
Get the starter code by using this link: Lab 1 creation link
if you had done lab 0, you will not need to do anything other than click the link to create this repo
if you had not, please fill in the team with your seneca user name (the part of the email before the @ symbol)
Learn a little markdown
Part A
Resource

In this part of the lab you are to do a number of mathematical exercises. There are two things you will need to do to submit your answers:

Provide the final answers 1 per line in the file lab1a.txt. For logarithms, use the cs default of base 2 if the base is unstate. The checker will check your results.
Provide your rough work as images in lab1.md.
Solve for x
*/
## Part A: Rough work
## Part A: Rough work

Put screenshots of the rough work for part A here
1.) x = (5)^2 = 25
2.) x = (2)^5 = 32
3.) 2^x = (2^6)(2^3) = 2^9 hence x = 9
4.) x = log(32) = 2^x = 32 hence x = 5
5.) x = log(8) = 2^x = 8 hence x = 3
6.) x = log(128) = 2^x = 128 hence x = 7
7.) x = log5 (125) hence 5^x = 125 so x = 3
8.) 2^x = 2^-5 hence x = -5 
9.) x = 2^x = 2^6 hence x = 6
10.) 2^x = 2^-4 hence x = -4 
11.) 2^x = 2^15 hence x = 15
12.) 2^x = 2^12 hence x = 12
13.) 2^x = 2(2^5) hence x = 6
14.) 2^(x-5) = 2^(3) hence x = 8
15.) 2^(4-x) = 2^-3 hence x = 7 
16.) 2^x =  2^(3+4)/2^(3*6) = 2^(7/18) hence x = 7/18
18.) x = log(.5) = 2^x = 1/2 hence x = -1
19.) log(8^x) = 3 log(8) hence 3x = 3(3) so x = 3
20.) x = 2^(log(16)) hence x = 16
21.) x = 2^(log(128)) hence x = 128
22.) x = 2^(log4) hence x = 4
23.) 2^x = 2(2^3)/2^4 hence x = ln(1)/ln(2) = 0
24.) 2^6 = log(32^x) hence 2^6 = log(2^5x) so 5x = 2^6 so x = 64/5
25.) log(x) + log(5) = log(15) hence 5x = 15 hence x = 3
Put screenshots of the rough work for part A here

## Part B: 

```c++
void bubbleSort(int arr[],int size){
    int tmp;                          
    for (int i=0; i<size-1; i++) {      // 1 + 2n + n-1
        for (int j=0; j<size-1; j++){   // (n-1)(1 + 2n + n-1)
            if (arr[j+1] < arr[j]) {    // 2(n-1)(n-1)
                tmp = arr[j];           // (n-1)(n-1)
                arr[j] = arr[j+1];      // 2(n-1)(n-1)  
                arr[j+1] = tmp;         // 2(n-1)(n-1)
            }
        }
    }
}
```

### 1. Express the number of operations as a function.

Let T(n) represent the maximum number of operations it takes to sort an array of size n using the code above. 

State T(n)
tmp = 1
for(i =0; i<size -1; i++>) = n-1 +1
another nested for loop for(i = 0; i<size; i++>) = n-1(n-1) +1
assignment of variable with array index all have value = 1 so 1 + (n-1)(n-1)(1)(1)(1)
so T(n) = n^2 -2*n +2
BigO - O(n^2)

### 2. Calculate operations

What is the maximum number of operations it takes to sort

    an array with 1000 values? Ans: T(1000) = (1000)^2 -2*(1000) +2 = 998002
    an array with 2000 values? Ans: T(2000) = (2000)^2 -2*(2000) +2 = 3996002
    an array with 3000 values? Ans: T(3000) = (3000)^2 -2*(3000) +2 = 8994002
    an array with 4000 values? Ans: T(4000) = (4000)^2 -2*(4000) +2 = 15992002
    an array with 5000 values? Ans: T(5000) = (5000)^2 -2*(5000) +2 = 24990002

### 3. Quadratic Sequence

Can you spot a relationship between the results in the previous part of this section and the quadratic sequence (1, 4, 9, 16, 25, ...)?


The Big O notation is O(n^2) = hence quadratic sequence 1^2 = 1, 2^2 = 4, 3^2 = 9, 4^2 = 16, 5^2 = 25
## Part C:

### Smallest number of guesses

Given any sample, what is the smallest number of guesses you would need to input in order to find the exact greyscale value of the sample using the device?

The number of guesses it would take is 8 if we use Binary search because it uses O(log2())
so in a combination of 255 for the gray scale it would take log(255)/log(2) = 8 hence 8 is the smaleest number of guess.
The reason Binary search algirithm is used is because you could do something more efficient than just guessing 1, 2, 3, 4, … from a set of number from 1 to 15 Since the computer tells you whether a guess is too low, too high, or correct, you can start off by guessing 8. If the number that the computer selected is less than 8, then because you know that 8 is too high, you can eliminate all the numbers from 8 to 15 from further consideration. If the number selected by the computer is greater than 8, then you can eliminate 1 through 8. Either way, you can eliminate half the numbers. On your next guess, eliminate half of the remaining numbers. Keep going, always eliminating half of the remaining numbers.
We call this halving approach binary search, and no matter which number from 1 to 15 the computer has selected, you should be able to find the number in at most 4 guesses with this technique. because log(16)/log(2) = 4
Here, try it for a number from 1 to 255. You should need no more than 8 guesses.
### Explanation

Explain how you would do this.
